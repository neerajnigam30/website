# VoyageVenue
A web application that replicates the core features of Airbnb, including property listings, booking functionality, user authentication, and reviews. Users can browse and search for accommodations, view property details, and book stays. The application also supports user profiles and management of listings. Built using Node.js, Express ,MongoDB
